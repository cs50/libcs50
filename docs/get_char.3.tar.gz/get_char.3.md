---
title: GET_CHAR
Author: [see the "AUTHOR(S)" section]
section: 3
header: CS50 Programmer's Manual
footer: CS50
date: 2024-04-25
Manual: CS50 Programmer's Manual
Source: CS50
Language: Englisch
---

<!-- Currently everything is indented with 3 spaces because at 4 the bold for print(3) stops working expect the c code and ##SEE ALSO -->

## NAME
   get_char - prompts user for a line of text from stdin and return the equivalent char 

## SYNOPSIS
**#include <cs50.h>**

**char get_char(const char \*format, ...);**

## DESCRIPTION
   Prompts user for a line of text from standart input and returns the
   equivalent char; if text is not a single char, user is reprompted.

   The prompt is formatted like **printf(3)**.

## RETURN VALUE
   Returns char equivalent to the line read from stdin. If line can't be read, returns **CHAR_MAX**.

## EXAMPLE
```c 
int main(void)
{
    // attempt to read character from stdin 
    char c = get_char("Enter char: ");

    // ensure character was read successfully
    if (c == CHAR_MAX)
    {
        return 1;
    }

    char next = get_char("You just entered %c. Enter antoher char: ",c);
    
    if (next == CHAR_MAX)
    {
        return 1;
    }

    printf("The last char you entered was %c\n", next);
}
```
<!-- indented with six -->
## SEE ALSO
      get_double(3), get_float(3), get_int(3), get_long(3),  
      get_string(3), printf(3)

