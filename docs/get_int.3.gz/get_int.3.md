---
title: GET_INT
Author: [see the "AUTHOR(S)" section]
section: 3
header: CS50 Programmer's Manual
footer: CS50
date: 2024-04-25
Manual: CS50 Programmer's Manual
Source: CS50
Language: Englisch
---

<!-- Currently everything is indented with 3 spaces because at 4 the bold for print(3) stops working expect the c code and ##SEE ALSO -->

## NAME
   get_int - prompts user for a line of text from stdin and returns the equivalent int 

## SYNOPSIS
**\#include <cs50.>**

**int get_int(const char \*format, ...);**

## DESCRIPTION
   Prompts user for a line of text from standard input and returns the equivalent int; if text does not represent an int or would cause overflow, user is 
   reprompted.

   The prompt is formatted like **printf(3)**.

## RETURN VALUE
   Returns the int equivalent to the line read fro stdin in \[**INT_MIN, INT_MAX**). If line can't be read, return **INT_MAX**.

## EXAMPLE
```c 
    /**
    * Returns the sum of two ints read from stdin, or INT_MAX if there was an error.
    */
    int add_ints(void)
    {
        // read int from stdin
        int i = get_int("Enter an int: ");

        // make sure we read one successfully
        if (i == INT_MAX)
        {
            return INT_MAX;
        }

        int j = get_int("What do you want to add %d to? ", i)

        if (j == INT_MAX)
        {
            return INT_MAX;
        }

        return i + j;
    }
```
<!-- indented with six -->
## SEE ALSO
      get_char(3), get_double(3), get_float(3), get_long(3),  
      get_string(3), printf(3)
